# CajeroBancarioPaulPark

saldo = 5000

print("Bienvenido al CajeroBancarioTEC, seleccione una opcion: ")

print("a. Ingreso")

print("b. Retiro")

print("c. Consulta")

print("d. Salir")

opcion = input()

if opcion = "a":

  print("Escriba el monto que desea ingresar: ")
  
  ingreso = input()
  
  saldo = saldo + ingreso
  
  print("Tu saldo actual es:"), saldo
  
if opcion = "b":

  print("Escriba el monto que desea retirar: ")
  
  retiro = input()
  
  saldo = saldo - retiro
  
  print("Tu saldo actual es:"), saldo
  
if opcion = "c":

  print("Tu saldo actual es:"), saldo
